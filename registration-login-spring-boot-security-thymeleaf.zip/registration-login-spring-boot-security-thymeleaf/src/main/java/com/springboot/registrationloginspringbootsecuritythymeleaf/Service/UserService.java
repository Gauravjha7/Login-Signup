package com.springboot.registrationloginspringbootsecuritythymeleaf.Service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.springboot.registrationloginspringbootsecuritythymeleaf.model.User;
import com.springboot.registrationloginspringbootsecuritythymeleaf.web.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService{
    User save(UserRegistrationDto registrationDto);
}